<?php $__env->startSection('content'); ?>
<!-- Dashboard Header -->
<div class="block-header">
    <div class="row remove-margin">
        <!-- Title -->
        <div class="col-md-4">
            <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
            <a href="" class="header-title-link">
                <h1><i class="fas fa-file-contract animation-expandUp"></i>Contratos<br><small>Bienvenido <?php echo e(Auth::user()->name); ?></small></h1>
            </a>
        </div>
        <!-- END Title -->

        <!-- Statistics -->
        <div class="col-md-8">
            <!-- Outer Grid -->
            <div class="row">
                <div class="col-sm-6">
                    <!-- Inner Grid 1 -->
                    <div class="row">
                        <div class="col-xs-6">
                            <a href="page_comp_charts.html" class="header-link">
                                <h1 class="animation-pullDown">
                                    <strong><?php echo e($files->count()); ?></strong><br><small>Archivos</small>
                                </h1>
                            </a>
                        </div>
                        
                    </div>
                    <!-- END Inner Grid 1 -->
                </div>
                <div class="col-sm-6">
                    <!-- Inner Grid 2 -->
                    <div class="row">
                        
                        
                    </div>
                    <!-- END Inner Grid 2 -->
                </div>
            </div>
            <!-- END Outer Grid  -->
        </div>
        <!-- END Statistics -->
    </div>
</div>
<ul class="breadcrumb breadcrumb-top">
    <li><i class="fas fa-file-contract"></i></li>
    <li><a href="<?php echo e(route('contracts.index')); ?>">Contratos</a></li>
    <li>Nuevo</li>
</ul>
<!-- END Dashboard Header -->

<!-- Dashboard Content -->
<div class="row gutter30">
    <div class="col-md-12">
        <form action="<?php echo e(route('contracts.store')); ?>" method="post" class="form-horizontal form-bordered" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <!-- Info Column -->
            <div class="col-md-6">


                <!-- Twitter Block -->
                <div class="block">
                    <!-- Twitter Title -->
                    <div class="block-title">
                        <h2><i class="fa fa-info-circle"></i> Info</h2>
                    </div>
                    <!-- END Twitter Title -->

                    <!-- Twitter Content -->
                    <ul class="list-unstyled">
                        <li>
                            <input type="hidden" name="signerOne" id="signerOne" value="<?php echo e($owner->name); ?>">
                            <input type="hidden" name="emailOne" id="emailOne" value="<?php echo e($owner->email); ?>">
                            <h6><span class="label label-default"><i class="fa fa-check-circle"></i> Datos del Emisor</span></h6>
                            <p><?php echo e($owner->name); ?></p>
                            <p><?php echo e($owner->email); ?></p>
                        </li>
                        <li>
                            <h6><span class="label label-default"><i class="fa fa-check-circle"></i> Datos del receptor</span></h6>
                            <?php if($guest_info): ?>
                                <p><?php echo e($guest_name); ?></p>
                                <p><?php echo e($guest_email); ?></p>
                            <?php else: ?>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <input type="text" id="signerTwo" name="signerTwo" class="form-control" placeholder="Escribe el nombre completo" autofocus required>
                                    </div>
                                </div>
                                <input type="hidden" name="emailTwo" id="emailTwo" value="<?php echo e($guest_email); ?>">
                                <p><?php echo e($guest_email); ?></p>
                            <?php endif; ?>

                        </li>
                        <li>
                            <input type="hidden" name="fileName" id="fileName" value="<?php echo e($file->name); ?>">
                            <h6><span class="label label-default"><i class="fa fa-check-circle"></i> Datos del Contrato</span></h6>
                            <p><?php echo e($file->name); ?></p>
                        </li>
                        
                    </ul>
                    <!-- END Twitter Content -->
                </div>
                <!-- END Twitter Block -->
            </div>
            <!-- END Info Column -->

            <!-- File Column -->
            <div class="col-md-6">
                <!-- Updates Block -->
                <div class="block">
                    <!-- Updates Title -->
                    <div class="block-title">
                        <h2><a href="<?php echo e(asset('storage')); ?>/<?php echo e($file->file); ?>" target="_blank"><i class="fa fa-file-pdf-o"></i></a> Resumen del contrato</h2>
                    </div>
                    <input type="hidden" name="file_path" id="file_path" value="<?php echo e($file_path); ?>">
                    <iframe width="100%" height="500" src="<?php echo e(asset('storage')); ?>/<?php echo e($file->file); ?>" frameborder="0"></iframe>


                </div>
                <!-- END Updates Block -->
            </div>
            <!-- END File Column -->


            <div class="form-group">
                <div class="col-sm-10 col-sm-offset-2">
                    <button type="reset" class="btn btn-sm btn-default"><i class="fa fa-times"></i> Borrar</button>
                    <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-arrow-right"></i> Enviar</button>
                </div>
            </div>
        </form>


    </div>
</div>
<!-- END Dashboard Content -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['activePage' => 'contracts', 'titlePage' => __('Confirmar')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ricardo/Proyectos/Tooring/Filex/resources/views/contracts/confirm.blade.php ENDPATH**/ ?>