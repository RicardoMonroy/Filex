<?php $__env->startSection('content'); ?>
<!-- Dashboard Header -->
<div class="block-header">
    <div class="row remove-margin">
        <!-- Title -->
        <div class="col-md-4">
            <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
            <a href="" class="header-title-link">
                <h1><i class="fa fa-home animation-expandUp"></i>Dashboard<br><small>Bienvenido <?php echo e(Auth::user()->name); ?></small></h1>
            </a>
        </div>
        <!-- END Title -->

        <!-- Statistics -->
        <div class="col-md-8">
            <!-- Outer Grid -->
            
            <!-- END Outer Grid  -->
        </div>
        <!-- END Statistics -->
    </div>
</div>
<ul class="breadcrumb breadcrumb-top">
    <li><i class="fa fa-home"></i></li>
    <li><a href="">Dashboard</a></li>
</ul>
<!-- END Dashboard Header -->

<!-- Dashboard Content -->
<div class="row gutter30">
    
    
</div>
<!-- END Dashboard Content -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', ['activePage' => 'dashboard', 'titlePage' => __('Dashboard')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ricardo/Proyectos/Tooring/Filex/resources/views/dashboard.blade.php ENDPATH**/ ?>