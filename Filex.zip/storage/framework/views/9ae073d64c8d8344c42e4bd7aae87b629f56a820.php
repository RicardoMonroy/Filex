<?php $__env->startSection('content'); ?>
<!-- Dashboard Header -->
<div class="block-header">
    <div class="row remove-margin">
        <!-- Title -->
        <div class="col-md-4">
            <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
            <a href="" class="header-title-link">
                <h1><i class="fas fa-file-contract animation-expandUp"></i>Archivos<br><small>Bienvenido <?php echo e(Auth::user()->name); ?></small></h1>
            </a>
        </div>
        <!-- END Title -->

        <!-- Statistics -->
        <div class="col-md-8">
            <!-- Outer Grid -->
            <div class="row">
                <div class="col-sm-6">
                    <!-- Inner Grid 1 -->
                    <div class="row">
                        <div class="col-xs-6">
                            <a href="page_comp_charts.html" class="header-link">
                                <h1 class="animation-pullDown">
                                    <strong><?php echo e($files->count()); ?></strong><br><small>Archivos</small>
                                </h1>
                            </a>
                        </div>
                        
                    </div>
                    <!-- END Inner Grid 1 -->
                </div>
                <div class="col-sm-6">
                    <!-- Inner Grid 2 -->
                    <div class="row">
                        
                        
                    </div>
                    <!-- END Inner Grid 2 -->
                </div>
            </div>
            <!-- END Outer Grid  -->
        </div>
        <!-- END Statistics -->
    </div>
</div>
<ul class="breadcrumb breadcrumb-top">
    <li><i class="fas fa-file-contract"></i></li>
    <li><a href="<?php echo e(route('files.index')); ?>">Archivos</a></li>
    <li><a href="">Mostrar</a></li>
</ul>
<!-- END Dashboard Header -->

<!-- Dashboard Content -->
<div class="row gutter30">
    <div class="col-md-12">
        <div class="row gutter30">
            <!-- First Column -->
            <div class="col-md-8">
                <!-- Updates Block -->
                <div class="block">
                    <!-- Updates Title -->
                    <div class="block-title">
                        <h2><a href="<?php echo e(asset('storage')); ?>/<?php echo e($file->file); ?>" target="_blank"><i class="fa fa-file-pdf-o"></a></i> <?php echo e($file->name); ?></h2>
                    </div>

                    <iframe width="100%" height="800" src="<?php echo e(asset('storage')); ?>/<?php echo e($file->file); ?>" frameborder="0"></iframe>


                </div>
                <!-- END Updates Block -->
            </div>
            <!-- END First Column -->

            <!-- Second Column -->
            <div class="col-md-4">


                <!-- Twitter Block -->
                <div class="block">
                    <!-- Twitter Title -->
                    <div class="block-title">
                        <h2><i class="fa fa-info-circle"></i> Info</h2>
                    </div>
                    <!-- END Twitter Title -->

                    <!-- Twitter Content -->
                    <ul class="list-unstyled">
                        <li>
                            <h6><span class="label label-default"><i class="fa fa-check-circle"></i> Nombre</span></h6>
                            <p><?php echo e($file->name); ?></p>
                        </li>
                        <li>
                            <h6><span class="label label-default"><i class="fa fa-check-circle"></i> Creado</span></h6>
                            <p><?php echo e($file->created_at->toFormattedDateString()); ?> (<?php echo e($file->created_at->DiffForHumans()); ?>)</p>
                        </li>
                        <li>
                            <h6><span class="label label-default"><i class="fa fa-check-circle"></i> Autor</span></h6>
                            <p><?php echo e($file->user->name); ?></p>
                        </li>
                        <li>
                            <h6><span class="label label-default"><i class="fa fa-check-circle"></i> email</span></h6>
                            <p><?php echo e($file->user->email); ?></p>
                        </li>
                    </ul>
                    <!-- END Twitter Content -->
                </div>
                <!-- END Twitter Block -->
            </div>
            <!-- END Second Column -->
        </div>

    </div>
</div>
<!-- END Dashboard Content -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'files', 'titlePage' => __('Mostrar')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ricardo/Proyectos/Tooring/Filex/resources/views/files/show.blade.php ENDPATH**/ ?>