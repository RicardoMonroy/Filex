<?php $__env->startSection('content'); ?>
<!-- Dashboard Header -->
<div class="block-header">
    <div class="row remove-margin">
        <!-- Title -->
        <div class="col-md-4">
            <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
            <a href="" class="header-title-link">
                <h1><i class="fas fa-file-contract animation-expandUp"></i>Contratos<br><small>Bienvenido <?php echo e(Auth::user()->name); ?></small></h1>
            </a>
        </div>
        <!-- END Title -->

        <!-- Statistics -->
        <div class="col-md-8">
            <!-- Outer Grid -->
            <div class="row">
                <div class="col-sm-6">
                    <!-- Inner Grid 1 -->
                    <div class="row">
                        <div class="col-xs-6">
                            <a href="page_comp_charts.html" class="header-link">
                                <h1 class="animation-pullDown">
                                    <strong><?php echo e($files->count()); ?></strong><br><small>Archivos</small>
                                </h1>
                            </a>
                        </div>
                        
                    </div>
                    <!-- END Inner Grid 1 -->
                </div>
                <div class="col-sm-6">
                    <!-- Inner Grid 2 -->
                    <div class="row">
                        
                        
                    </div>
                    <!-- END Inner Grid 2 -->
                </div>
            </div>
            <!-- END Outer Grid  -->
        </div>
        <!-- END Statistics -->
    </div>
</div>
<ul class="breadcrumb breadcrumb-top">
    <li><i class="fas fa-file-contract"></i></li>
    <li>Contratos</li>
</ul>
<!-- END Dashboard Header -->

<!-- Dashboard Content -->
<div class="row gutter30">
    <div class="col-md-12">
        <!-- Search Block -->
        <div class="clearfix">
            <div class="btn-group btn-group-sm pull-right push">
                <a href="<?php echo e(route('contracts.create')); ?>" class="btn btn-primary" id="style-hover"><i class="fas fa-plus"></i> Nuevo</a>
            </div>
            <div class="btn-group btn-group-sm pull-left push" data-toggle="buttons">
                <p>Aquí se encuentran todos tus contratos.</p>
            </div>
        </div>
            <div class="table-responsive">
                <table id="example-datatable" class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th class="text-center">#</th>
                            <th>Nombre</th>
                            <th>Archivo</th>
                            <th>Invitado</th>
                            <th class="text-center">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                    </tbody>
                </table>
            </div>
    </div>
</div>
<!-- END Dashboard Content -->
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', ['activePage' => 'contracts', 'titlePage' => __('Mis Contratos')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ricardo/Proyectos/Tooring/Filex/resources/views/contracts/index.blade.php ENDPATH**/ ?>