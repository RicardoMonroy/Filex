<?php $__env->startSection('content'); ?>
<!-- Dashboard Header -->
<div class="block-header">
    <div class="row remove-margin">
        <!-- Title -->
        <div class="col-md-4">
            <!-- If you do not want a link in the header, instead of .header-title-link you can use a div with the class .header-section -->
            <a href="" class="header-title-link">
                <h1><i class="fas fa-file-contract animation-expandUp"></i>Contratos<br><small>Bienvenido <?php echo e(Auth::user()->name); ?></small></h1>
            </a>
        </div>
        <!-- END Title -->

        <!-- Statistics -->
        <div class="col-md-8">
            <!-- Outer Grid -->
            <div class="row">
                <div class="col-sm-6">
                    <!-- Inner Grid 1 -->
                    <div class="row">
                        <div class="col-xs-6">
                            <a href="page_comp_charts.html" class="header-link">
                                <h1 class="animation-pullDown">
                                    <strong><?php echo e($files->count()); ?></strong><br><small>Archivos</small>
                                </h1>
                            </a>
                        </div>
                        
                    </div>
                    <!-- END Inner Grid 1 -->
                </div>
                <div class="col-sm-6">
                    <!-- Inner Grid 2 -->
                    <div class="row">
                        
                        
                    </div>
                    <!-- END Inner Grid 2 -->
                </div>
            </div>
            <!-- END Outer Grid  -->
        </div>
        <!-- END Statistics -->
    </div>
</div>
<ul class="breadcrumb breadcrumb-top">
    <li><i class="fas fa-file-contract"></i></li>
    <li><a href="<?php echo e(route('contracts.index')); ?>">Contratos</a></li>
    <li>Nuevo</li>
</ul>
<!-- END Dashboard Header -->

<!-- Dashboard Content -->
<div class="row gutter30">
    <div class="col-md-12">
        <form action="<?php echo e(route('contracts.confirm')); ?>" method="post" class="form-horizontal form-bordered" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="col-sm-2 control-label" for="bordered-username">Nombre del Evento</label>
                <div class="col-sm-4">
                    <input type="text" id="name" name="name" class="form-control" placeholder="Ej. Firma de compraventa">
                </div>
            </div>

            <div class="form-group">
                <label class="col-sm-2 control-label" for="bordered-username">Correo del invitado</label>
                <div class="col-sm-4">
                    <input type="email" id="email" name="email" class="form-control" placeholder="Ej. usuario@ejemplo.com">
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-2 control-label" for="example-select">Archivo</label>
                <div class="col-md-4">
                    <select id="file" name="file" class="form-control" size="1">
                        <option value="0">Selecciona un Archivo</option>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($file->id); ?>"><?php echo e($file->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>


            <div class="form-group">
                <div class="col-sm-10 col-sm-offset-2">
                    <button type="reset" class="btn btn-sm btn-default"><i class="fa fa-times"></i> Borrar</button>
                    <button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-arrow-right"></i> Seguir</button>
                </div>
            </div>
        </form>


    </div>
</div>
<!-- END Dashboard Content -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', ['activePage' => 'contracts', 'titlePage' => __('Nuevo')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ricardo/Proyectos/Tooring/Filex/resources/views/contracts/create.blade.php ENDPATH**/ ?>