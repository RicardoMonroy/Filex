<?php

namespace App\Http\Controllers;

use App\File;
use App\User;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;
use Mifiel\Document;

class ContractController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $files = File::whereUserId(Auth::user()->id)->OrderBy('id', 'desc')->get();

        $documents = Document::all();

        return view('contracts.index', compact('files'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $files = File::whereUserId(Auth::user()->id)->OrderBy('id', 'desc')->get();

        return view('contracts.create', compact('files'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // TODO: Seguir con el tema de la API
        $document = new Document([
            // 'original_hash' => hash('sha256', file_get_contents($request->file_path)),
            // 'name' => $request->fileName,
            'file_path' => $request->file_path,
            // 'file_path' => 'http://www.aliat.org.mx/BibliotecasDigitales/derecho_y_ciencias_sociales/Derecho_civil_III.pdf',
            'signatories' => [
              [
                'name' => $request->signerOne,
                'email' => $request->emailOne,
                'tax_id' =>  'AAA010101AAA'
              ],
              [
                'name' => $request->signerTwo,
                'email' => $request->emailTwo,
                'tax_id' =>  'AAA010102AAA'
              ]
            ]
          ]);

          $document->save();

          $files = File::whereUserId(Auth::user()->id)->OrderBy('id', 'desc')->get();

          Toastr::success('Parece que se almacenó tu documento.','Bien');
          return redirect()->route('contracts.index', compact('files'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function confirm(Request $request)
    {
        $files = File::whereUserId(Auth::user()->id)->OrderBy('id', 'desc')->get();
        $owner = Auth::user();
        $name = $request->name;

        if($guest = User::where('email', $request->email)->first()){
            $guest_name = User::where('email', $request->email)->first()->name;
            $guest_email = User::where('email', $request->email)->first()->email;
            $guest_info = 1;
        }else{
            $guest_name = "Nombre del invitado";
            $guest_email = $request->email;
            $guest_info = 0;
        }

        if($file = File::where('id', $request->file)->first()){
            $file = File::where('id', $request->file)->first();
            $file_path = config('app.url').Storage::url($file->file);
        }else{
            $file = "Algo salió mal...";
        }



        return view('contracts.confirm', compact('files', 'owner', 'guest_name', 'guest_email', 'guest_info', 'name', 'file', 'file_path'));
    }
}
